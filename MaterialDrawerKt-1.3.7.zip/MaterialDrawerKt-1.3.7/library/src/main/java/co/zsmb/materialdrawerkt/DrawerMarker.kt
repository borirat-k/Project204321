@file:Suppress("RedundantVisibilityModifier")

package co.zsmb.materialdrawerkt

@DslMarker
internal annotation class DrawerMarker
